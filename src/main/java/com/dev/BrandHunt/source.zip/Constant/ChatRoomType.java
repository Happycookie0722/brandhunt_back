package com.dev.BrandHunt.Constant;

public enum ChatRoomType {
    SINGLE,
    GROUP
}
