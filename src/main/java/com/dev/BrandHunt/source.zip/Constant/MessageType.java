package com.dev.BrandHunt.Constant;

public enum MessageType {
    TEXT,
    IMAGE,
    FILE
}
