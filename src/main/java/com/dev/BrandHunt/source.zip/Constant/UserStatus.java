package com.dev.BrandHunt.Constant;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
